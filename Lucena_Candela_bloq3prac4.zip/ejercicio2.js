$(document).ready(function(){
    $("#cambiar").click(function(){
        $("p").cambiartamaño();
    })
}) 