$(document).ready(function(){   
   $("#desaparecer").click(function(){
      $("p").ocultar();
   })
}) 