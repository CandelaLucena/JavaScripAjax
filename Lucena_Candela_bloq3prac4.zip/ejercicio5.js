$( function() {
    $( "#accordion" ).accordion();
  } );