<?php
echo("Hola mundo");
?>