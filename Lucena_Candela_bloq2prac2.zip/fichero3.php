<?php 
    $texto = $_POST["texto"];
    echo("este es tu texto: ".$texto);
?>