<?php 
    $dni = $_GET["dni"];
    echo("este es tu dni: ".$dni);
?>